#!/usr/bin/env python3
"""Claude Code hook'u: bir alt ajan başlarken ve bitince OZMIRA'ya olay yollar.

Claude Code bu dosyayı hook olarak çalıştırır ve olayı stdin'den JSON olarak verir.
Hiçbir koşulda Claude Code'u durdurmaz: hata olursa sessizce çıkar (çıkış kodu 0).
Sistem kimliği OZMIRA_SISTEM ortam değişkeninden okunur (varsayılan: claude).
"""
import json
import os
import subprocess
import sys


def main():
    try:
        d = json.load(sys.stdin)
    except Exception:
        return
    if not isinstance(d, dict):
        return
    ti = d.get("tool_input") if isinstance(d.get("tool_input"), dict) else {}
    ajan = ti.get("subagent_type") or d.get("agent_type") or ""
    olay = {"PreToolUse": "basla", "PostToolUse": "bitti", "SubagentStop": "bitti"}.get(d.get("hook_event_name"))
    if not olay or not isinstance(ajan, str) or not ajan.strip():
        return
    komut = [sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), "ozmira.py"), "olay",
             os.environ.get("OZMIRA_SISTEM", "claude"), ajan.strip()[:60], olay]
    tr = d.get("tool_response") if isinstance(d.get("tool_response"), dict) else {}
    tok = tr.get("totalTokens")
    if olay == "bitti" and isinstance(tok, (int, float)) and not isinstance(tok, bool) and 0 <= tok <= 1e9:
        komut.append(str(int(tok)))
    kul = tr.get("usage") if isinstance(tr.get("usage"), dict) else {}
    if olay == "bitti":
        for ad, alan in (("girdi", "input_tokens"), ("cikti", "output_tokens")):
            v = kul.get(alan)
            if isinstance(v, (int, float)) and not isinstance(v, bool) and 0 <= v <= 1e9:
                komut.append("%s=%d" % (ad, int(v)))
    try:
        subprocess.run(komut, timeout=8, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


if __name__ == "__main__":
    try:
        main()
    finally:
        sys.exit(0)
