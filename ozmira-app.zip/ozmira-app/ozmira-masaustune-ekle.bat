@echo off
setlocal
cd /d "%~dp0"
set PY=
where py >/dev/null 2>/dev/null && set PY=py
if not defined PY where python >/dev/null 2>/dev/null && set PY=python
if not defined PY (
  echo Python: https://www.python.org/downloads/
  pause
  exit /b 1
)
%PY% ozmira.py kisayol
pause
