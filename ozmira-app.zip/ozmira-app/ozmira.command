#!/bin/sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then exec python3 ozmira.py "$@"; fi
if command -v python >/dev/null 2>&1; then exec python ozmira.py "$@"; fi
echo "Python bulunamadi. https://www.python.org/downloads/ adresinden kurun."
read -r _
