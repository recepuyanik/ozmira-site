#!/bin/sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then exec python3 ozmira.py --uygulama "$@"; fi
if command -v python >/dev/null 2>&1; then exec python ozmira.py --uygulama "$@"; fi
echo "Python: https://www.python.org/downloads/"
read -r _
